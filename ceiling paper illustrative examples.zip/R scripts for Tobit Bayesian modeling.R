
require(rjags)
require(coda)
library(runjags)


realdata <- read.table('ttestdata.txt')

# Example 1: Dependent-sample t-tests when both x1 (pretest) and x2 (posttest) have ceiling effects ---------
ntime = 2
n=nrow(realdata)
x1<-realdata[,1]
x2<-realdata[,2]

# create an indicator for censoring, 1 = censored or have ceiling effects, 0 = not censored or does not have ceiling effect
ind.x1=x1
ind.x1[ind.x1 < max(x1)] = 0
ind.x1[ind.x1== max(x1)] = 1
ind.x2=x2
ind.x2[ind.x2 < max(x2)] = 0
ind.x2[ind.x2== max(x2)] = 1
ind.x = cbind(ind.x1, ind.x2)

# replace ceiling data as missingness (NA)
cen.x1=x1
cen.x2=x2
is.na(cen.x1) = ind.x1 == 1
is.na(cen.x2) = ind.x2 == 1
cen.x = cbind(cen.x1, cen.x2)

# create ceiling thresholds as the max values of x1 and x2
ctx = c(max(x1), max(x2))

# create initial levels for cen.x1 and cen.x2 by adding a small number
x1.int=x1+0.1 # add 0.1
is.na(x1.int) = ind.x1 == 0 # cen.x1.int=NA if status=0 (not censored)
x2.int=x2+0.1 # add 0.1
is.na(x2.int) = ind.x2 == 0 # cen.x2.int=NA if status=0 (not censored)
x.int = cbind(x1.int, x2.int)

model <- "model{
  # specify likelihood of x1 and x2 
    for(i in 1:n){
    for(j in 1:ntime){
        ind.x[i,j] ~ dinterval(cen.x[i,j], ctx[j])
        cen.x[i,j] ~ dnorm(mux[i,j],taue) # taue = 1/sigmae^2, e_1i and e_2i are independent and their variance is the same
    }
  }
  
  # specify means of x1 and x2, and eta[i,2] represents mean difference between x1 and x2
  for (i in 1:n){
    mux[i,1] <- eta[i,1]
    mux[i,2] <- eta[i,1]+eta[i,2]
    eta[i,1] ~ dnorm(mueta[1], taueta[1])
    eta[i,2] ~ dnorm(mueta[2], taueta[2])
  }
  
  # specify priors
  mueta[1] ~ dnorm(0, 1.0E-6)
  mueta[2] ~ dnorm(0, 1.0E-6)
  taueta[1] ~ dgamma(0.001,0.001)
  taueta[2] ~ dgamma(0.001,0.001)
  taue ~ dgamma(0.001,0.001)
  vare = 1/taue
  vareta1=1/taueta[1]
  vardiff=1/taueta[2]
  # calculate mean difference and Cohen's d 
  mdiff = mueta[2] # mean difference
  d = mdiff/sqrt(vardiff+2*vare) # cohen's d value
  varpre=vareta1+vare
  varpost=vareta1+vardiff+vare
}"

writeLines(model, "t_tobit.txt")

model.inits1 = list(taue=0.1, mueta= rep(0,2), taueta = rep(1,2),cen.x=x.int)
model.inits2 = list(taue=0.5, mueta= rep(0.5,2), taueta = rep(0.5,2),cen.x=x.int)
initlisttobit<-list(model.inits1, model.inits2)

datalist = list(n=n,ntime=ntime, ind.x = ind.x, cen.x=cen.x,ctx=ctx)

tout.tobit <- run.jags(model=model, 
                      monitor=c("mdiff","d","varpre","varpost","vare","mueta","vareta1"),
                      data=datalist, 
                      n.chains=2,
                      inits=initlisttobit, method="simple", adapt=10000, burnin = 30000,
                      sample=60000, thin=1, keep.jags.files=FALSE, tempdir=FALSE)


summary(tout.tobit)
plot(tout.tobit)


# Example 2: Moderated regression when both focal preditor x and outcome y have ceiling effects ---------
realdata <- read.table('moderationdata.txt')
n=nrow(realdata)
x<-realdata[,1]
y<-realdata[,2]
z<-realdata[,3]/10 # scale
# create an indicator for censoring, 1 = censored or have ceiling effects, 0 = not censored or does not have ceiling effect
ind.x=x
ind.x[ind.x < max(x)] = 0
ind.x[ind.x== max(x)] = 1
ind.y=y
ind.y[ind.y < max(y)] = 0
ind.y[ind.y == max(y)] = 1

# replace ceiling data as missingness (NA)
cen.x=x
cen.y=y
is.na(cen.x) = ind.x == 1
is.na(cen.y) = ind.y == 1

# create ceiling thresholds as the max values of x and y
ctx=max(x)
cty=max(y)

# create initial levels for cen.x and cen.y by adding a small number
x.int=x+0.1 # add 0.1
is.na(x.int) = ind.x == 0 # tx1.int=NA if status=1 (not censored)
y.int=y+0.1 # add 0.1
is.na(y.int) = ind.y == 0 # tx1.int=NA if status=1 (not censored)



modregtobit <- "model{
  for (i in 1:n){
     ind.x[i]~dinterval(cen.x[i], ctx)
     cen.x[i]~dnorm(mu.x, pre.phi.x)
     ind.y[i]~dinterval(cen.y[i], cty)
     muy[i]<-beta[1]+beta[2]*cen.x[i]+beta[3]*z[i]+beta[4]*cen.x[i]*z[i]
     cen.y[i]~dnorm(muy[i],pre.phi.y)
  }
  for (j in 1:4){
     beta[j]~dnorm(0, 1.0E-6)
  }
  pre.phi.y~dgamma(.001,.001)
  resvar<-1/pre.phi.y
  mu.x ~ dnorm(0,1.0E-6)
  pre.phi.x~dgamma(.001,.001)
  varx<-1/pre.phi.x
}"


writeLines(modregtobit, "modregtobit.txt")


model.inits1 <- list(beta=c(0,0,0,0), pre.phi.y=1.5, pre.phi.x=0.3, mu.x=0, cen.x = x.int, cen.y = y.int)
model.inits2 <- list(beta=c(0,0,0,0), pre.phi.y=1,pre.phi.x=0.3, mu.x=0.5, cen.x = x.int, cen.y = y.int)
initlisttobit<-list(model.inits1, model.inits2)


out.tobit <- run.jags(model=modregtobit, monitor=c("beta","resvar","varx","mu.x"),
data=list(n=n, ind.y=ind.y, ind.x=ind.x, cen.y=cen.y, cen.x=cen.x, z=z,ctx=ctx,cty=cty), n.chains=2,
inits=initlisttobit, method="simple", adapt=10000, burnin = 30000,
sample=100000, thin=1, keep.jags.files=TRUE, tempdir=TRUE)


summary(out.tobit)
plot(out.tobit)

