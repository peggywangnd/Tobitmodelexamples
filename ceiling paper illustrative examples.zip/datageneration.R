
library("mvtnorm")

setwd('')
set.seed(301)  # Ensure reproducibility

# Generate data
# t-test
n <- 96
mu = c(11.09,11.09+0.38)
sigma = matrix(c(2.93,2.269,2.269, 3.642),2,2)
d = (mu[2]-mu[1])/sqrt(3.2+3.9-2*2.46)
data = rmvnorm(n, mean = mu, sigma = sigma)
x = data[,1]
y = data[,2]
var(y)
x[x > 12] <- 12
y[y > 12] <- 12

data <- data.frame(x = x, y = y)

# Check results
summary(data)
mean(data$x == 12)  # Should be close to 30%
mean(data$y == 12)  
max(data$y)  # ceiling threshold = 12

write.table(data, file = "ttestdata.txt", row.names = FALSE, col.names = FALSE)

# moderation
set.seed(299)
n <- 96
# x and z, mean and variance using 
mu = c(11.12, 5.040)
sigma = matrix(c(3.13,0.40*sqrt(3.13*0.787),0.40*sqrt(3.13*0.787), 0.787),2,2)
predictor =  rmvnorm(n, mean = mu, sigma = sigma)
x <- predictor[,1]
z <- predictor[,2]
y <- -3.63 + 1.21* x + 1.45 * z - 0.1 * z * x + rnorm(n, 0, sqrt(1.90))
x[x > 12] <- 12
y[y > 12] <- 12
z = z * 10
# Store in dataframe
data <- data.frame(x = x, y = y, z = z)
write.table(data, file = "moderationdata.txt", row.names = FALSE, col.names = FALSE)
# Check results
summary(data)
mean(data$x == 12)  # Should be close to 30%
mean(data$y == 12)  
max(data$y)  # # ceiling threshold = 12
max(data$z)  
z = z/10
conventional = lm(y ~ x*z)
summary(conventional)
